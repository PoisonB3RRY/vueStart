<template>
    <div>
        {{ msg }}
    </div>
</template>
<script>
export default {
    data(){
        return{
            msg:"123456"
        }
    }
}
</script>

