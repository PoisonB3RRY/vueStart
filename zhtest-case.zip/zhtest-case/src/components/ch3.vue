<template>
    <div class="hello">
        <h1>{{ msg }}</h1>
        <!-- <child></child> -->
    </div>
</template>
<script>
// import child from "./sub/child"
export default {
    data(){
        return {
            msg:"78910"
        }
    },
    // components:{
    //     child
    // }
}
</script>

