import Vue from 'vue'
import Router from 'vue-router'
import ch1 from '@/components/ch1'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'ch1',
      component: ch1
    }
  ]
})
