import { shallowMount } from '@vue/test-utils';
import ch3 from '@/components/ch3'

// 拦截掉 .vue 文件的内容
jest.mock('@/components/sub/child.vue', () => ({
  render(h) {
    h();
  },
}));

describe('test ch1', () => {
  it('should render correct contents', () => {
    const wrapper = shallowMount(ch3);
    expect(wrapper.find('.hello h1').text())
      .toEqual('78910');
  });
});