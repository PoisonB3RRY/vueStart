import { shallowMount } from '@vue/test-utils';
import ch1 from '@/components/ch1'

describe('test ch1', () => {
  it('should render correct contents', () => {
    const wrapper = shallowMount(ch1);
    expect(wrapper.find('.hello h1').text())
      .toEqual('欢迎你来学习 Vue 单元测试！');
  });
});