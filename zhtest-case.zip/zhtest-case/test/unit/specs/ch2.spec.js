import { shallowMount } from '@vue/test-utils';
import ch2 from '@/components/ch2'

describe('test ch2', () => {
    const wrapper = shallowMount(ch2);
    it("update 'msg' correctly", () => {
        // 点击 button
        wrapper.find('button').trigger('click');
        wrapper.vm.$nextTick().then(function () {
            expect(wrapper.find('h1').text())
                .toEqual('new message');
        });
    });
});