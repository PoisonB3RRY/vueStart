import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div class="iframe">
      <h3>欢迎来到 angular 世界</h3>
      <a href="/user">用户中心2</a>
      <router-outlet></router-outlet>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'vue-qiankun-ngchild';
}
