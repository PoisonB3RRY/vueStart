let add=(x,y)=>{
    return x+y;
}


export {
    add
}