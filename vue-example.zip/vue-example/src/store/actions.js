const actions={
    add_stus_act(context,data){
        context.commit("add_stus",data)
    }
}
export default actions