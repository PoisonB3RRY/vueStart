<template>
    <div class="frame">
        {{msg}}
        <div><button @click="_add(10,20)">调用全局方法</button></div>
        <div><button @click="_start()" :disabled="blnShow">定义全局对象</button></div>
        <div v-if="blnShow">
            <a href="#/b">进入第2页面</a>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                msg: "...",
                blnShow: false
            }
        },
        methods: {
            // 1.调用全局的方法
            _add(x, y) {
                let str = "数字 " + x + "+" + y + " = "
                this.msg = str + this.$add(x, y);
            },
            // 2.定义全局对象
            _start() {
                this.num = 9;
                this.chat._createNum(this.num);
                this.ws = ["123", "456"];
                this.chat._createObj(this.ws);
                setInterval(() => {
                    this.chat._pushObj("789");
                    this.chat._addNum();

                    this.chat.i++;
                    this.chat.arr.push("789")

                    this.blnShow = true;
                }, 1000)
            }
        }
    }
</script>

<style scoped>

</style>


