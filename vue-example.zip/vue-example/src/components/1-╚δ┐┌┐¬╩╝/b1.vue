<template>
    <div class="frame">
        {{num}}
        <div>
            <button @click="showNum">显示数字</button>
        </div>
        {{num2}}
        <div>
            <button @click="showNum2">普通数字</button>
        </div>
        {{length}}
        <div>
            <button @click="showObj">显示对象</button>
        </div>
        {{length2}}
        <div>
            <button @click="showObj2">普通对象</button>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                num: "...",
                num2: "...",
                length: "...",
                length2: "..."
            }
        },
        methods: {
            showNum() {
                this.num = "数字累加值是：" + this.chat.num;
            },
            showNum2() {
                this.num2 = "数字累加值是：" + this.chat.i;
            },
            showObj() {
                this.length = "数组的长度是：" + this.chat.ws.length;
            },
            showObj2() {
                this.length2 = "数组的长度是：" + this.chat.arr.length;
            }
        }
    }
</script>

