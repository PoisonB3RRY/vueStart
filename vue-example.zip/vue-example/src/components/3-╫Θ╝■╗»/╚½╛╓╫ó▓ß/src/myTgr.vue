<template>
    <div class="frame">
       {{tip}}
    </div>
</template>

<script>
export default {
      name:'myTgr',
      data(){
          return{
              tip:'今天的天气非常好'
          }
      }
}
</script>

<style>
.frame{
    margin-top:15px;
}
</style>
