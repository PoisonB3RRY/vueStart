<template>
    <div>
       <my-tgr></my-tgr>
    </div>
</template>

<script>
export default {
     data(){
         return{

         }
     }
}
</script>

<style>

</style>
