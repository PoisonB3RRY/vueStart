import myTgr from './src/myTgr'

myTgr.install = (Vue) => {
  Vue.component(myTgr.name, myTgr)
}

export default myTgr