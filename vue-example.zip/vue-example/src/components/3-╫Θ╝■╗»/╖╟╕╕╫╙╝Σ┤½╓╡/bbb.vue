<template>
  <div class="act">
    B组件:
    <span>{{name}}</span>
  </div>
</template>

<script>
  import Bus from './bus'
  export default {
    name: 'bbb',
    data() {
      return {
        name: 0
      }
    },
    mounted: function() {
      var vm = this
      // 用$on事件来接收参数
      Bus.$on('elementByValue', (data) => {
        vm.name = data
      })
    }
  }
</script>

<style scoped>
  
</style>