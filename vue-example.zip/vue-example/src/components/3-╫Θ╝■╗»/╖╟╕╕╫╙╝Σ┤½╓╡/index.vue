<template>
    <div class="frame">
        <h3>组件之间传值：</h3>
        <bbb></bbb>
        <aaa></aaa>
    </div>
</template>

<script>
    import aaa from "./aaa"
    import bbb from "./bbb"
    export default {
        name: "index",
        components: {
            aaa: aaa,
            bbb: bbb
        }
    }
</script>

<style>
    .frame {
        margin: 15px 0px;
    }
    .act {
        width: 100%;
        margin: 10px 0px;
        background-color: #eee;
        padding: 10px;
        border: solid 1px #ccc;
    }
</style>


