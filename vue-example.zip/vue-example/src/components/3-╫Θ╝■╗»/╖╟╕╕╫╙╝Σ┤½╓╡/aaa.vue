<template>
  <div class="act">
    A组件: <input type="number" v-model="num" />
    <input type="button" value="点击触发" @click="elementByValue()">
  </div>
</template>

<script>
  // 引入公共的bug，来做为中间传达的工具
  import Bus from './bus'
  export default {
    name: 'aaa',
    data() {
      return {
        num: 0
      }
    },
    methods: {
      elementByValue: function(e) {
        Bus.$emit('elementByValue', this.num);
      }
    }
  }
</script>