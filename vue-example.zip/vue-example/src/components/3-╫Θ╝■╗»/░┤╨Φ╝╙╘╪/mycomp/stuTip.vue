<template>
    <div class="tip">
       获取的数据是：{{val}}
    </div>
</template>
<script>
export default {
    name: "stuTip",
    props: {
        val: {
            type: String,
            required: true
        }
    }
}
</script>
<style scoped>

</style>


