<template>
    <div class="frame">
        <div v-if="istip">
            <stu-tip :val="val"></stu-tip>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                istip: false,
                val: ""
            }
        },
        mounted: function() {
            // 获取提示信息
            this.$http.get("http://rttop.cn/api/?day=1-1").then((data) => {
                if (data.data) {
                    this.istip = true;
                    this.val = data.data;
                }
            })
        },
        components: {
            stuTip: () => (
                import ('./mycomp/stuTip'))
        }
    }
</script>

