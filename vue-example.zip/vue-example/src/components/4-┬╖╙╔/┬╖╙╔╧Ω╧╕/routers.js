let login = {
    template: '<h2>这是登录页</h2>'
}
let register = {
    template: '<h2>这是注册页</h2>'
}
let news = {
    template: '<h2>这是新闻页</h2>'
}
let hots = {
    template: '<h2>这是热点页</h2>'
}
const header = {
    template: `<div>这是头部组件</div>`
}
const main = {
    template: `<div>这是主体组件</div>`
}
const footer = {
    template: `<div>这是底部组件</div>`
}
export {
    login,
    register,
    news,
    hots,
    header,
    main,
    footer
}