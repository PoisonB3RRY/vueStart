<template>
    <div>
        <h3>路由的配置</h3>
        <router-link to="/log">登录</router-link>
        <router-link to="/reg">注册</router-link>
    </div>
</template>
<script>
export default {
    name:"index"
}
</script>
<style scoped>
      
</style>


