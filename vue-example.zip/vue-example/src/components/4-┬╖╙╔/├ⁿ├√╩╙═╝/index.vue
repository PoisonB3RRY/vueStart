<template>
    <div>
        <h3>命名视图：</h3>
    </div>
</template>
<script>
export default {
    name:"index"
}
</script>

