<template id="tmp1">
    <div>
        <h3>路由嵌套</h3>
        <router-link to="/bbb/news">新闻</router-link>
        <router-link to="/bbb/hots">热点</router-link>
        <router-view></router-view>
    </div>
</template>
<script>
    export default {
        name: "index"
    }
</script>

