<template>
    <div class="frame">
        <h3>接收路由传值：</h3>
        <div class="act">
            <router-link :to="{path:'/test',query: {id: 123,ab:456}}">跳转</router-link>
            <router-link :to="'/test/456'">跳转</router-link>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'ccc',
        methods: {}
    }
</script>

<style scoped>
    .frame {
        margin: 15px 0px;
    }
    .act {
        width: 100%;
        margin: 10px 0px;
        background-color: #eee;
        padding: 10px;
        border: solid 1px #ccc;
    }
</style>
