<template>
    <div class="frame">
        <h3>接收路由传值：</h3>
        <div class="act">
            <template v-if="num==1">
                    <div>接收到的值是:id={{id}}</div>
                    <button @click="getV()">获取</button>
</template>

<template v-else-if="num==2">
    <div>
        接收到的值是:cid={{cid}}</div>
    <button @click="getV2()">获取</button>
</template>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'test',
        data() {
            return {
                id: '',
                cid: '',
                num: 0
            }
        },
        mounted() {
            if (this.$route.query.id != undefined) {
                this.num = 1;
            } else {
                this.num = 2;
            }
        },
        methods: {
            getV: function() {
                this.id = this.$route.query.id
            },
            getV2: function() {
                this.cid = this.$route.params.cid
            }
        }
    }
</script>

<style scoped>
    .frame {
        margin: 15px 0px;
    }
    .act {
        width: 100%;
        margin: 10px 0px;
        background-color: #eee;
        padding: 10px;
        border: solid 1px #ccc;
    }
    .act div {
        margin-bottom: 5px;
    }
</style>
