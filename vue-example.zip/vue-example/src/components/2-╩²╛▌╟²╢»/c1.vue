<template>
    <div class="frame">
        <ul>
            <li>
                <span>名称</span>
                <span>价格</span>
                <span>数量</span>
                <span></span>
            </li>
            <li v-for="(item,index) in shop" :key="index">
                <span>{{item.name}}</span>
                <span>{{item.price}}</span>
                <span @click="down(index)" class="span">-</span>
                <input type="text" class="txt" v-model="item.count">
                <span @click="up(index)" class="span">+</span>
            </li>
        </ul>
        <div style="clear:both">
            <span>总数量：{{sumNum}}</span>
            <span>总价格：{{sumPrice}}元</span>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'c1',
        data() {
            return {
                total: 0,
                sumNum:0,
                sumPrice:0,
                shop: [{
                        id: 10001,
                        name: 'iphone',
                        count: 1,
                        price: 200
                    },
                    {
                        id: 10002,
                        name: 'book',
                        count: 3,
                        price: 300
                    }
                ]
            }
        },
        watch: {
            'shop': {
                handler: function(oldvalue, newvalue) {
                    this.sumNum = 0;
                    this.sumPrice = 0;
                    this.shop.forEach((item) => {
                        this.sumNum += item.count;
                        this.sumPrice += item.count * item.price;
                    })
                },
                deep:true,
                immediate:true
            }
        },
        methods: {
            up: function(i) {
                this.shop[i].count++;
            },
            down: function(i) {
                this.shop[i].count--;
            }
        }
    }
</script>

<style scoped>
    .frame {
        margin: 15px 0px;
    }
    .frame>div {
        margin: 15px 10px;
    }
    .frame>div>span {
        margin-right: 30px;
    }
    ul {
        list-style: none;
        width: 400px;
        margin: 0px;
        padding: 0px;
        overflow: hidden;
    }
    ul li {
        float: left;
        border-bottom: dashed 1px #ccc;
        padding: 8px 10px;
    }
    ul li:first-child {
        font-weight: bold;
        background-color: #eee;
    }
    ul li span {
        width: 90px;
        display: inline-block;
    }
    ul li .span {
        width: 20px;
        display: inline-block;
        cursor: pointer;
    }
    ul .txt {
        width: 30px;
    }
</style>


