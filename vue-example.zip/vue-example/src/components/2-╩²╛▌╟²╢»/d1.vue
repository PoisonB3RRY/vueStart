<template>
    <div class="frame">
        当前页面数据 <time>{{dt}}</time>
        <div>
            <a :href="url" class="btn">手动刷新</a>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            dt: (new Date()).getTime(),
            url: ""
        }
    },
    mounted(){
        setInterval(()=>{
             this.url = "#/d?pid=123&cid=456&v="+(new Date()).getTime();
        },1000)
    },
    watch:{
        "$route":{
            handler:function(){
                this.dt=(new Date()).getTime()
            },
            immediate:true
        }
    }
}
</script>

<style>
.frame{
    margin-top:15px;
}
.btn{
    border: solid 1px #666;
    background-color: #eee;
    padding: 3px 8px;
    border-radius: 4px;
    color:#000;
}
</style>
