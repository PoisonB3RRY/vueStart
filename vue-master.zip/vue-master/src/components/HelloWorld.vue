<template>
  <div>
    <h3>{{title}}</h3>
    <p>{{desc}}</p>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        title: '基座主页-主题',
        desc: '主页-副标题'
      }
    }
  }
</script>

<style scoped>

</style>