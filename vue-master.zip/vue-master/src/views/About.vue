<template>
  <div class="about">
   <h3>{{title}}</h3>
   <p>{{desc}}</p>
  </div>
</template>
<script>
export default {
  data(){
    return{
        title:'基座关于页-主题',
        desc:'关于页-副标题'
    }
  }
}
</script>

