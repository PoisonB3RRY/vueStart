var express = require('express');
var app = express();
var fs = require('fs');

app.get('/', function (req, res) {
    var layoutHtml = fs.readFileSync(__dirname + "/layout.html").toString();
    res.write(layoutHtml);

    // setTimeout模拟异步返回
    setTimeout(function () {
        res.write('<script>loadPipe.view("#moduleA","模块一");</script>');
    }, 1000);

    setTimeout(function () {
        res.write('<script>loadPipe.view("#moduleB","模块二");</script>');
    }, 2000);

    setTimeout(function () {
        res.write('<script>loadPipe.view("#moduleC","模块三");</script>');
        res.write('</body></html>');
    }, 3000);

    setTimeout(function () {
        res.end();
    }, 4000);
});
app.listen(3030);
console.log("http://localhost:3030/");