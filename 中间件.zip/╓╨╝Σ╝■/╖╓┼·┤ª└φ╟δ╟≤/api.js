var express = require('express');
var app = express();
var request = require("request");

var n = m = 0;

new Promise(function (success, fail) {
    request('http://rttop.cn/api/?day=1-1', function (error, response, body) {
        n++;
        if (!error && response.statusCode == 200) {
            console.log("----------------------");
            console.log("第" + n + "次请求接口:" + body);
            success(body);
        }
    })
}).then(val => {
    app.get("/", function (req, res) {
        m++;
        //设置页面内容编码的格式
        res.header("Content-Type", "text/html; charset=utf-8");
        //设置允许跨域的域名，*代表允许任意域名跨域
        res.header("Access-Control-Allow-Origin", "*");
        console.log("----------------------");
        console.log("第" + m + "次请求中间件:" + val);
        // res.write("<title>请求页</title>");
        res.write(val + "，你的职业是:程序员！");
        res.end();
    })
})
app.listen(3040);
console.log("http://localhost:3040/");