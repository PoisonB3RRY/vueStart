var add = require('./add.js');
var rev = require('./rev.js');

var expect = require('chai').expect;




describe('函数的测试', function() {
    it('加法函数', function() {

        expect(add(1, 2)).to.be.equal(3);


    });

    it('反向输出内容', function() {

        expect(rev('123456')).to.be.equal('654321');
        
    });
});