var tgrong={
    rev:function (v) {
        return v.split('').reverse().join('')
    }
}
module.exports=tgrong.rev