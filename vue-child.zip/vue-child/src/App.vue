<template>
  <div class="app-main">
    <div class="app-nav" v-if="showMenu">
      <router-link to="/home">
        <div class="nav-a-btn">child-home</div>
      </router-link>
      <router-link to="/about">
        <div class="nav-a-btn">child-about</div>
      </router-link>
    </div>
    <div class="app-content">
      <div class="app-header-content" v-if="showHeader"></div>
      <div class="app-container">
        <router-view></router-view>
      </div>

    </div>
  </div>

</template>
<script>
import { mapState } from "vuex"
export default {
  computed: {
    ...mapState(["token"]),
    showMenu() {
      return this.token && !this.isMicroEnc
    },
    showHeader() {
      return this.token && !this.isMicroEnc
    },
    isMicroEnc() {
      return window.__POWERED_BY_QIANKUN__
    }

  }
}
</script>

<style lang="scss">
html,
body {
  margin: 0;
  padding: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
.app-main {
  display: flex;
  justify-content: space-between;
  width: 100%;
  height: 100vh;

  background: #f6f7fc;
  text-align: center;
}
.app-nav {
  width: 160px;
  height: 100%;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0px 10px 0px rgb(0, 47, 60, 0.2);
  padding: 20px;
  box-sizing: border-box;
  background: #fff;
  z-index: 2;

  a {
    font-weight: bold;
    color: #2c3e50;
    margin-bottom: 10px;
    text-decoration: none;

    &.router-link-exact-active {
      color: #42b983;
      .nav-a-btn {
        background: #deeefdde;
      }
    }
  }
  .nav-a-btn {
    width: 100%;
    height: 40px;
    line-height: 40px;
    background: #f3f4f5;
  }
}
.app-content {
  width: calc(100% - 160px);
  height: 100%;
  .app-header-content {
    padding: 0 20px;
    width: 100%;
    height: 50px;
    background: #ffffff;
    box-shadow: 0px 0px 8px 0px rgb(0 0 0 / 8%);
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-sizing: border-box;
  }
  .app-container {
    width: 100%;
    height: calc(100% - 50px);
    text-align: left;
    padding: 20px;
    box-sizing: border-box;
  }
}
</style>
