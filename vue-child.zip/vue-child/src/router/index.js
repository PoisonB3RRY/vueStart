import Home from '../views/Home.vue'
// 判断环境是否是微应用打开
let microPath = ''
if (window.__POWERED_BY_QIANKUN__) {
  microPath = '/vue2-micro-app'
}

const routes = [
  {
    path: microPath + '/',
    redirect: microPath + '/home'
  },
  {
    name: 'Home',
    path: microPath + '/home',
    component: Home
  },
  {
    name: 'About',
    path: microPath + '/about',
    component: () => import('../views/About.vue')
  },
  {
    name: 'login',
    path: microPath + '/login',
    component: () => import('../views/login.vue')
  }
]

export default routes
