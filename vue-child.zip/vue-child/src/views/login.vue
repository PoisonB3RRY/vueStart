<template>
  <div class="">
    <div><span>账号：</span><input type="text" v-model="name"></div>
    <div><span>密码：</span><input type="text" v-model="password"></div>
    <button @click="childLogin">login</button>
  </div>
</template>

<script>
  import MicroActions from '@/qiankun/qiankun-actions'
  export default {
    data() {
      return {
        name: '',
        password: ''
      };
    },
    mounted() {
      MicroActions.onGlobalStateChange((state, prevState) => {
        // state: 变更后的状态; prevState: 变更前的状态
        console.log("子应用观察者：状态改变", state, prevState);
      }, true)
    },
    methods: {
      childLogin() {
        let tokens = this.name + '&' + this.password
        this.$store.commit("setToken", tokens)
        MicroActions.setGlobalState({
          globalToken: tokens
        })
        let microPath = "";
        if (window.__POWERED_BY_QIANKUN__) {
          microPath = "/vue2-micro-app";
        }
        this.$router.push({
          path: microPath + "/"
        })
        console.log("child-token ", tokens)
      }
    },
  };
</script>

<style lang="scss" scoped>

</style>
