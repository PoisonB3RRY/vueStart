<template>
  <div class="home">
    <button @click="gotoParent">跳转主应用</button>
    <button @click="gotoMyself">跳转内部</button>
    <button @click="gotoLogin">子应用登录</button>
    <HelloWorld msg="子应用主页" />
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  methods: {
    gotoParent() {
      console.log("主应用传来的router实例", this.$microRouter)
      if (window.__POWERED_BY_QIANKUN__) {
        this.$microRouter.push("/master-home");
      }
    },
    gotoMyself() {
      let microPath = ''
      if (window.__POWERED_BY_QIANKUN__) {
        microPath = "/vue2-micro-app";
      }

      this.$router.push({ path: microPath + "/about" })

    },
    gotoLogin() {
      let microPath = ''
      if (window.__POWERED_BY_QIANKUN__) {
        microPath = "/vue2-micro-app";
      }

      this.$router.push({ path: microPath + "/login" })
    }
  }
}
</script>
<style lang="scss" scoped>
.home button{
  margin-right: 10px;
}
</style>

