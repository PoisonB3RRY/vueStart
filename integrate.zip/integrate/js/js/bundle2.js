window.a2=`
    <h3>title</h3>
    <p1>第二个页面</p1>
`