window.a3=`
    <h3>title</h3>
    <p1>第三个页面</p1>
`