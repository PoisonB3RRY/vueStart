//引入path模块，nodejs中的系统模块
const path = require("path");
//引入 HtmlWebpackPlugin 插件
const HtmlWebpackPlugin = require("html-webpack-plugin");
//引入 MiniCssExtractPlugin 插件
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

//引入 exports 模块
module.exports = {
    mode:"production",//生产模式
    //入口
    entry:"./src/app.js",
    //出口
    output:{
        path:path.resolve(__dirname,"dist"),//__dirname是nodejs系统模块，用于表示当前文件的绝对路径
        filename:'demo.bundle.js'//出口文件
    },
    plugins:[
      new HtmlWebpackPlugin({
        template:'./src/index.html',//指定作为模版 html 文件
      }),
      new MiniCssExtractPlugin() //new MiniCssExtractPlugin 实例对象且做配置
    ],
    module: {
      rules: [
        {
          test: /\.css$/, //使用正则匹配选取扩展名为 .css 结尾的文件
          /**
           * 上面 test 选取的文件内容由 MiniCssExtractPlugin.loader、css-loader 处理转化
           * 使用 MiniCssExtractPlugin.loader 将注入的 CSS 提取到单独 CSS 文件中，默认为 main.css
           */
          use: [MiniCssExtractPlugin.loader,"css-loader"],
        },
      ]
    },
    //开发服务器
    devServer:{
      // allowedHosts:[".simplelab.cn"],//将允许访问开发服务器的服务器（域名）列入白名单
      // publicPath: path.join(__dirname,"dist"),（webpack-cli v4.8.0 和 webpack-dev-server v4.0.0 不支持该配置）
      // contentBase:path.join(__dirname,"dist"),//设置服务器访问的基本目录（webpack-cli v4.8.0 和 webpack-dev-server v4.0.0 不支持该配置）
      host:'127.0.0.1',//服务器地址，localhost
      compress:true,//一切服务都启用 gzip 压缩
      port:8088,//端口号，如果 deServer 的配置没问题，但是项目启动失败了，需要注意该端口号是否被占用
      // open:true,//浏览器自动打开
      hot:true,//webpack 4 之前的版本的配置：热更新，4以后被弱化不需要被配置会自动刷新
      disableHostCheck: true,//域名可访问 （webpack-cli v4.8.0 和 webpack-dev-server v4.0.0 不支持该配置）
    }
}