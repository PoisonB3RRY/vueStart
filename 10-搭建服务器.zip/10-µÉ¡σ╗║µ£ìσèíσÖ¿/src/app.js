import "./app.css";

//1.动态加载import内容
import { i, add, name, hello } from './outfile';

console.log("执行前i的值是:" + i);
add();
console.log("执行后i的值是:" + i);
hello();

document.getElementById("app").innerText = "今天的天气非常好6";

//2.如果热更新状态
if (module.hot) {
    //执行相应更新
    module.hot.accept();
}
//监控相关热更新的状态值
module.hot.addStatusHandler(status => {
    // 响应当前状态……
    console.log('当前状态是:' + status);
})
console.log("前端开发2");