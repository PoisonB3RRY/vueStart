export let i=60;
export function add(){
   i++;
}
export function hello(){
    console.log('今天天气不错');
}

export let name='程序世界'