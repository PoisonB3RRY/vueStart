<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="less">
#app {
  padding: 0;
  margin: 0;
  height: 100%;
  min-width: 1200px;
}
</style>
