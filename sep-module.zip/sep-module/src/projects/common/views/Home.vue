<template>
  <div>
    我是公用项目
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
