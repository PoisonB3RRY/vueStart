<template>
  <div>
    我是B项目,该项碰到问题，估计后一解决！
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
