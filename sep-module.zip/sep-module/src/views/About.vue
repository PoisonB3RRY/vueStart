<template>
    <div>
        关于我们
    </div>
</template>
<script>
export default {
    data(){
        return{

        }
    }
}
</script>
<style scoped>

</style>


